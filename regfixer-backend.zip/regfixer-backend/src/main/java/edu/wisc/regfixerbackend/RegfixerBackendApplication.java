package edu.wisc.regfixerbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegfixerBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegfixerBackendApplication.class, args);
	}

}
