package edu.wisc.regfixerbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegfixerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
